A Pen created at CodePen.io. You can find this one at https://codepen.io/graphilla/pen/gGgWKM.

 Modern retro block clock made from 60 'pixels'.

Starting building this with no idea where it was heading. Result turned out OK.