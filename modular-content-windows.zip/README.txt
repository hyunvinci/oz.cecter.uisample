A Pen created at CodePen.io. You can find this one at https://codepen.io/MrHill/pen/BnyLx.

 Separate windows each displaying a different type of content (Similar to a desktop window). Resizable, maximizeable, skinnable, movable, etc. 