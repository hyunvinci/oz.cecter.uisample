A Pen created at CodePen.io. You can find this one at https://codepen.io/tjramage/pen/yOEbyw.

 React implementation of a sortable drag and drop list organised into columns.